package it.mws2018002.hellotre;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import it.mws2018002.hellotre.dto.StudenteDTO;

public class MainActivity extends AppCompatActivity {
    public static final String PAR_MSG      = "MSG";
    public static final String PAR_PREZZO   = "PREZZO";
    public static final String PAR_RESULT   = "RESULT";
    public static final String PAR_STUDENTE = "STIDENTE";

    public static final int RESULT_CODE_SECONDA_ACTIVITY   = 5001;
    public static final int RESULT_CODE_REGISTER           = 5002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void faiQualcosa(View view){
        //EditText et = findViewById(R.id.casella_di_testo);
        //Log.d("LELE", "ho cliccato faiQualcosa(): "+ et.getText());
        TextView tv = findViewById(R.id.a1_risultato);
        //tv.setText( et.getText() );
        tv.setText( getEditTextValue( R.id.a1_casella_di_testo ) );
    }


    public void apriSecondActivity(View view) {
        Intent i = new Intent(this, SecondActivity.class);
        String msg = getEditTextValue( R.id.a1_casella_di_testo );
        i.putExtra(MainActivity.PAR_MSG, msg);
        i.putExtra(MainActivity.PAR_PREZZO, 12.34D);
        //startActivity( i );

        StudenteDTO s = new StudenteDTO("Lele", "Rizzo", 21);
        i.putExtra( MainActivity.PAR_STUDENTE, s );

        startActivityForResult( i, MainActivity.RESULT_CODE_SECONDA_ACTIVITY );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("LELE", "on activity result");
        if( requestCode==MainActivity.RESULT_CODE_SECONDA_ACTIVITY ){
            Log.d("LELE", "torno da SecondActivity");
            if( resultCode==Activity.RESULT_OK ){
                Log.d("LELE", "   ho un risultato");
                Log.d("LELE", "----> "+ data.getBooleanExtra(MainActivity.PAR_RESULT, false));
            }
            if( resultCode==Activity.RESULT_CANCELED ){
                Log.d("LELE", "   non ho un risultato");
            }
        }


        if( requestCode==MainActivity.RESULT_CODE_REGISTER ){
            if( resultCode==Activity.RESULT_OK ){
                TextView matTV = findViewById(R.id.a1_matricola);
                matTV.setText( data.getStringExtra(RegisterActivity.RESULT_MATRICOLA));
            }
            if( resultCode==Activity.RESULT_CANCELED ){
                Toast.makeText(this, "PECCATO :-(", Toast.LENGTH_LONG).show();
            }
        }
    }

    private String getEditTextValue(int id ){
        EditText et = findViewById( id );
        //if( et==null ) return null;   // meglio non fare controlli di questo tipo
        return ""+et.getText();
    }
    private Integer getEditTextValueInt(int id ){
        EditText et = findViewById( id );
        //if( et==null ) return null;   // meglio non fare controlli di questo tipo
        return new Integer(""+et.getText());
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.d("LIFECYCLE", "Main ---> onStart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d("LIFECYCLE", "Main ---> onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("LIFECYCLE", "Main ---> onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.d("LIFECYCLE", "Main ---> onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("LIFECYCLE", "Main ---> onDestroy");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.d("LIFECYCLE", "Main ---> onBackPressed");
    }

    public void clickSulLayout(View view) {
        Log.d("LELE","Click sul layout");
    }

    public void registra(View view) {
        String  n = getEditTextValue(    R.id.a1_in_nome );
        String  c = getEditTextValue(    R.id.a1_in_cognome );
        Integer e = getEditTextValueInt( R.id.a1_in_eta );
        StudenteDTO s = new StudenteDTO(n, c, e);

        Intent i = new Intent(this, RegisterActivity.class);
        i.putExtra(MainActivity.PAR_STUDENTE, s);
        startActivityForResult(i, MainActivity.RESULT_CODE_REGISTER);
    }
}
