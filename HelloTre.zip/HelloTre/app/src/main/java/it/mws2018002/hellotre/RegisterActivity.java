package it.mws2018002.hellotre;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import it.mws2018002.hellotre.dto.StudenteDTO;

public class RegisterActivity extends AppCompatActivity {
    public static final String RESULT_MATRICOLA = "MATRICOLA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Intent i = getIntent();
        StudenteDTO s = (StudenteDTO) i.getSerializableExtra(MainActivity.PAR_STUDENTE);
        setTextViewVaue( R.id.a3_nome,    s.getNome());
        setTextViewVaue( R.id.a3_cognome, s.getCognome());
        setTextViewVaue( R.id.a3_eta,     s.getEta());
    }

    private void setTextViewVaue(int id, String value){
        TextView t = findViewById(id);
        t.setText( ""+ value );
    }
    private void setTextViewVaue(int id, int value){
        TextView t = findViewById(id);
        t.setText( ""+ value );
    }
    public void conferma(View view) {
        String matricola = "MT_1004";
        Intent i = new Intent();
        i.putExtra(RegisterActivity.RESULT_MATRICOLA, matricola);
        setResult(Activity.RESULT_OK, i);
        finish();
    }
}
