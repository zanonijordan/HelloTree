package it.mws2018002.hellotre;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;

import it.mws2018002.hellotre.dto.StudenteDTO;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent i = getIntent();
        String msg = i.getStringExtra( MainActivity.PAR_MSG );
        double prezzo = i.getDoubleExtra( MainActivity.PAR_PREZZO, -1D );
        Log.d("LELE", "Msg: "+ msg);
        Log.d("LELE", "Prezzo: "+ prezzo);

        StudenteDTO s = (StudenteDTO) i.getSerializableExtra(MainActivity.PAR_STUDENTE);
        Log.d("LELE", "Nome:    "+ s.getNome());
        Log.d("LELE", "Cognome: "+ s.getCognome());
        Log.d("LELE", "Età:     "+ s.getEta());
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("LIFECYCLE", "Second ---> onStart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d("LIFECYCLE", "Second ---> onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("LIFECYCLE", "Second ---> onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.d("LIFECYCLE", "Second ---> onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("LIFECYCLE", "Second ---> onDestroy");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.d("LIFECYCLE", "Second ---> onBackPressed");
    }

    public void vediSeAttivo(View view) {
        CheckBox a = findViewById(R.id.a2_attivo);
        Log.d("LELE", "Attivo: "+ a.isChecked() + " ("+a.getText() +")");
    }

    public void ritornaValore(View view) {
        CheckBox cb = findViewById(R.id.a2_attivo);
        boolean b = cb.isChecked();

        Intent i = new Intent();
        i.putExtra(MainActivity.PAR_RESULT, b);
        setResult(Activity.RESULT_OK, i);
        finish();
    }

    public void annulla(View view) {
        setResult(Activity.RESULT_CANCELED);
        finish();
    }
}
