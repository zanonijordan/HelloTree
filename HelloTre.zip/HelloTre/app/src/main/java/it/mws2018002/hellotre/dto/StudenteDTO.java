package it.mws2018002.hellotre.dto;

import java.io.Serializable;

public class StudenteDTO implements Serializable {
    private String nome;
    private String cognome;
    private Integer eta;

    public StudenteDTO( String n, String c, Integer e ){
        this.nome = n;
        this.cognome = c;
        this.eta = e;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public Integer getEta() {
        return eta;
    }

    public void setEta(Integer eta) {
        this.eta = eta;
    }
}
